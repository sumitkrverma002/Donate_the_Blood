<?php 

	//include header file
	include ('include/header.php');

?>

<style>
	.size{
		padding: 80px 0px;
	}
	img{
		width: 300px;
		height: 300px;
	}
	h2{
		color: #e74c3c;
	}
	.white{
		background-color: white;
	}
	p{
		font-size: 18px;
	}
	.right{
		float: right;
	}
	h1{
		color: white;
	}
	.size{
		min-height: 0px;
		padding: 60px 0 40px 0;
		
	}

</style>
<div class="container-fluid red-background size">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h1 class="text-center">About Us</h1>
			<hr class="white-bar">
		</div>
	</div>
</div>
<div class="container-fluid size">
	
	<div class="container">
		<div class="row">
		<div class="col-md-6"><img src="img/binoculars.png" alt="Our Vission" class="rounded float-left img-fluid"></div>
		<div class="col-md-6">
			<h2 class="text-center">Our Vission</h2>
			<hr class="red-bar">
			<p>
				Our vision for "Donate the Blood" is to create a life-saving platform that connects blood donors with recipients in need, ensuring timely and efficient access to blood in emergency situations. By leveraging modern technology, we aim to build a comprehensive network of donors across various cities, promoting community-driven support and enhancing public health. Our platform aspires to facilitate quick, reliable communication between donors and recipients, ultimately fostering a culture of altruism and solidarity. Through continuous innovation and user-centric design, "Donate the Blood" seeks to save lives and make a significant impact on healthcare accessibility and emergency response.


			</p>
			
		</div>
	</div>
	</div>
</div>

<div class="container-fluid white size">
	<div class="container ">
	<div class="container">
		<div class="row ">
		<div class="col-md-6">
			<h2 class="text-center">About Our Team</h2>
			<hr class="red-bar">
			<p>
				Our team at "Donate the Blood" is composed of dedicated professionals passionate about saving lives and improving public health. With expertise in healthcare, technology, and community outreach, we are committed to creating an efficient and user-friendly platform that connects blood donors with those in need. Our diverse team brings together specialists in software development, database management, and digital marketing to ensure the platform's reliability and reach. United by a common goal, we work tirelessly to foster a culture of altruism, streamline emergency response, and make a positive impact on healthcare accessibility in communities nationwide.
				<br>
				Md Jabir Shah - Developer
				<br>
				Sumit Kumar - Front-end Developer
				<br>
				Pooja Kumari - UI/UX Design
				<br>
		
			</p>
			<p>
				<img src="img/jabir.jpg" alt="Md Jabir Shah" style="width:200px;height:220px">
				<img src="img/sumit.jpg" alt="Sumit Kumar" style="width:200px;height:220px">
				<img src="img/pooja.jpg" alt="Pooja Kumari" style="width:200px;height:220px">
				<img src="img/anisul.jpg" alt="Anisul" style="width:200px;height:220px">
			</p>
		</div>
		<div ><img src="img/target.png" alt="Our Vission" class="rounded img-fluid float-right"></div>
	</div>
	</div>		
</div>
</div>
	

	<div class="container-fluid size">
		<div class="container">
		<div class="row">
		<div class="col-md-6"><img src="img/goal.png" alt="Our Vission" class="rounded float-left img-fluid"></div>
		<div class="col-md-6">
			<h2 class="text-center">Our Mission</h2>
			<hr class="red-bar">
			<p>
				At "Donate the Blood," our mission is to bridge the gap between blood donors and recipients, ensuring no one suffers due to a lack of blood availability. We strive to build a robust, accessible platform that facilitates quick and reliable communication and coordination in times of need. Our goal is to foster a compassionate community of donors, driven by the spirit of altruism and solidarity. Through continuous innovation and user-centered design, we aim to enhance public health, support emergency medical services, and ultimately save lives by making blood donation a seamless and impactful experience.
			</p>
		</div>
	</div>
	</div>
	</div>
<?php 

	//include footer file
	include ('include/footer.php');

?>
