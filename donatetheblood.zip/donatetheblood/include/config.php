<?php

	$connecion = mysqli_connect("localhost","root","","donatetheblood") or dia("Database is not connected." .mysqli_connect_error());
?>